package megalodonte.props;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import megalodonte.base.scale.ScaleProvider;
import megalodonte.base.theme.ThemeInterface;
import megalodonte.styles.util.StyleUtils;

import static megalodonte.styles.util.StyleUtils.applyBackgroundStyling;

public class RowProps extends LayoutProps<RowProps> {
    protected String bgColor;
    protected boolean fillWidth;
    private boolean fillHeight = false;

    public RowProps bgColor(String bgColor) {
        this.bgColor = bgColor;
        return this;
    }

    public RowProps fillWidth(){
        fillWidth = true;
        return this;
    }

    /** Deixa a Row esticar verticalmente se o pai (uma VBox) oferecer mais espaço, em vez de travar na altura preferida dos filhos (comportamento padrão, ver {@link megalodonte.components.layout_components.Row}). */
    public RowProps fillHeight() {
        this.fillHeight = true;
        return this;
    }

    public boolean hasFillHeight() {
        return fillHeight;
    }

    private boolean hugWidth = false;

    /** Faz a Row não ocupar toda a largura disponível: a largura fica limitada à soma da largura dos filhos (comportamento padrão do HBox é ser esticado pela Row, ver {@link megalodonte.components.layout_components.Row}). */
    public RowProps hugWidth() {
        this.hugWidth = true;
        return this;
    }

    public boolean hasHugWidth() {
        return hugWidth;
    }

    @Override
    protected void applyTheme(Node node, Props props, ThemeInterface theme) {
        if (node instanceof HBox hBox) {
            applyBaseLayout(node, theme);

            if (spacingUnits > 0) {
                hBox.setSpacing(ScaleProvider.scale(spacingUnits));
            }

            if (alignment == Alignment.BOTTOM_VERTICALLY) {
                hBox.setAlignment(Pos.BOTTOM_LEFT);
            }
            if (alignment == Alignment.CENTER_HORIZONTALLY) {
                hBox.setAlignment(Pos.CENTER);
            }
            if (alignment == Alignment.CENTER_VERTICALLY) {
                hBox.setAlignment(Pos.CENTER_LEFT);
            }
            if (alignment == Alignment.LEFT_HORIZONTALLY) {
                hBox.setAlignment(Pos.TOP_LEFT);
            }
            if (alignment == Alignment.RIGHT_HORIZONTALLY) {
                hBox.setAlignment(Pos.TOP_RIGHT);
            }

            if(fillWidth){
                HBox.setHgrow(hBox, Priority.ALWAYS);
            }

            if (fillHeight) {
                hBox.setMaxHeight(Double.MAX_VALUE);
                VBox.setVgrow(hBox, Priority.ALWAYS);
            }

            if(bgColor != null){
                StyleUtils.applyBackgroundStyling(node, theme, bgColor);
            }
        }
    }

    private enum Alignment {BOTTOM_VERTICALLY, CENTER_HORIZONTALLY, CENTER_VERTICALLY, LEFT_HORIZONTALLY, RIGHT_HORIZONTALLY}
    private Alignment alignment;

    public RowProps bottomVertically() {
        alignment = Alignment.BOTTOM_VERTICALLY;
        return this;
    }

    public RowProps leftHorizontally() {
        alignment = Alignment.LEFT_HORIZONTALLY;
        return this;
    }

    public RowProps centerHorizontally() {
        alignment = Alignment.CENTER_HORIZONTALLY;
        return this;
    }

    public RowProps centerVertically() {
        alignment = Alignment.CENTER_VERTICALLY;
        return this;
    }

    public RowProps rightHorizontally() {
        alignment = Alignment.RIGHT_HORIZONTALLY;
        return this;
    }
}
