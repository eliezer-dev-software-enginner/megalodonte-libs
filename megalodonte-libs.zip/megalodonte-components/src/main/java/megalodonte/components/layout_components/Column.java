package megalodonte.components.layout_components;

import javafx.scene.control.ScrollPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import megalodonte.base.components.Component;
import megalodonte.components.SpacerVertical;
import megalodonte.props.ColumnProps;
import megalodonte.base.state.ForEachState;

import java.util.List;

public class Column extends Component implements LayoutComponent {
    private final VBox vBox;
    private VBox itemsVBox = null;
    private final ColumnProps columnProps;

    public Column(){
        this(new ColumnProps());
    }

    public Column(ColumnProps props){
        super(new VBox(), props);
        this.vBox = (VBox) this.node;
        this.columnProps = props;
    }

    public Column c_child(Component component){
        this.vBox.getChildren().add(component.getJavaFxNode());

        if (component instanceof SpacerVertical c) {
            VBox.setVgrow(c.getJavaFxNode(), Priority.ALWAYS);
        }

//        if (component.props instanceof ButtonProps buttonProps) {
//            Insets margins = buttonProps.getMargins();
//            if (margins != null) {
//                VBox.setMargin(component.getJavaFxNode(), margins);
//            }
//        }

        return this;
    }

    @Override
    public Column items(List<? extends Component> components) {
        for (Component c : components) {
            c_child(c);
        }
        return this;
    }

    /**
     * Constrói os filhos a partir de uma lista comum (não reativa), aplicando
     * {@code mapper} a cada item. Use {@link #items(ForEachState)} quando a lista
     * precisar reagir a mudanças de estado.
     */
    public <T> Column items(List<T> data, java.util.function.Function<T, ? extends Component> mapper) {
        for (T item : data) {
            c_child(mapper.apply(item));
        }
        return this;
    }

    public <T, C extends Component > Column items(ForEachState<T, C> forEachState, int spacing) {
        // Só pode ser chamado uma vez por Column
        if (this.itemsVBox != null) {
            throw new IllegalStateException("items() só pode ser chamado uma vez por Column");
        }
        
        // Cria VBox separado para os itens dinâmicos
        this.itemsVBox = new VBox(spacing);
        this.vBox.getChildren().add(this.itemsVBox);
        
        // Adiciona os componentes iniciais
        List<C> componentes = forEachState.getComponents();
        for (C component : componentes) {
            this.itemsVBox.getChildren().add(component.getJavaFxNode());
        }
        
        // Se inscreve para atualizar automaticamente quando o estado mudar
        forEachState.getState().subscribe(newItems -> {
            // Limpa completamente o VBox dos itens
            this.itemsVBox.getChildren().clear();
            
            // Adiciona os componentes atualizados
            List<C> novosComponentes = forEachState.getComponents();
            for (C component : novosComponentes) {
                this.itemsVBox.getChildren().add(component.getJavaFxNode());
            }
        });
        
        return this;
    }

    public <T, C extends Component > Column items(ForEachState<T, C> forEachState) {
     return this.items(forEachState,0);
    }

    @Override
    public <T, C extends Component > Column items(ForEachState<T, C> forEachState, boolean isScrollable) {
        if (this.itemsVBox != null) {
            throw new IllegalStateException("items() só pode ser chamado uma vez por Column");
        }

        this.itemsVBox = new VBox();

        if (isScrollable) {
            ScrollPane scrollPane = new ScrollPane(this.itemsVBox);
            scrollPane.setFitToWidth(true);    // itemsVBox ocupa a largura total do ScrollPane
            scrollPane.setFitToHeight(false);  // altura livre para rolar verticalmente
            scrollPane.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
            scrollPane.setVbarPolicy(ScrollPane.ScrollBarPolicy.AS_NEEDED);
            VBox.setVgrow(scrollPane, Priority.ALWAYS); // ScrollPane expande dentro da Column pai
            megalodonte.components.Scroll.confineScrollEvents(scrollPane);
            this.vBox.getChildren().add(scrollPane);
        } else {
            this.vBox.getChildren().add(this.itemsVBox);
        }

        // Adiciona os componentes iniciais
        List<C> componentes = forEachState.getComponents();
        for (C component : componentes) {
            this.itemsVBox.getChildren().add(component.getJavaFxNode());
        }

        // Atualiza automaticamente quando o estado mudar
        forEachState.getState().subscribe(newItems -> {
            this.itemsVBox.getChildren().clear();

            List<C> novosComponentes = forEachState.getComponents();
            for (C component : novosComponentes) {
                this.itemsVBox.getChildren().add(component.getJavaFxNode());
            }
        });

        return this;
    }
    public ColumnProps props() {
        return columnProps;
    }

    @Override
    public Column children(Component... components) {
        for (Component c : components) {
            c_child(c);
        }
        return this;
    }
}
