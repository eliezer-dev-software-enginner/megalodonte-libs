package megalodonte.props;

import javafx.scene.Node;
import javafx.scene.layout.Region;
import megalodonte.base.scale.ScaleProvider;
import megalodonte.base.theme.ThemeInterface;

public abstract class LayoutProps<T extends LayoutProps<T>> extends Props implements Paddable<T> {
    protected double minWidth = -1;
    protected double maxWidth = -1;
    protected double width = -1;
    protected double maxHeight = -1;
    protected double height = -1;
    protected int spacingUnits = 0;
    protected int paddingUnitsTop = UNSET;
    protected int paddingUnitsRight = UNSET;
    protected int paddingUnitsDown = UNSET;
    protected int paddingUnitsLeft = UNSET;
    protected Runnable onClick;

    @SuppressWarnings("unchecked")
    public T minWidth(double minWidth) {
        this.minWidth = minWidth;
        return (T) this;
    }

    @SuppressWarnings("unchecked")
    public T maxWidth(double maxWidth) {
        this.maxWidth = maxWidth;
        return (T) this;
    }

    @SuppressWarnings("unchecked")
    public T width(double width) {
        this.width = width;
        return (T) this;
    }

    @SuppressWarnings("unchecked")
    public T maxHeight(double maxHeight) {
        this.maxHeight = maxHeight;
        return (T) this;
    }

    @SuppressWarnings("unchecked")
    public T height(double height) {
        this.height = height;
        return (T) this;
    }

    @SuppressWarnings("unchecked")
    public T spacingOf(int units) {
        this.spacingUnits = units;
        return (T) this;
    }

    @Override
    public int getPaddingUnitsTop() { return paddingUnitsTop; }

    @Override
    public int getPaddingUnitsRight() { return paddingUnitsRight; }

    @Override
    public int getPaddingUnitsDown() { return paddingUnitsDown; }

    @Override
    public int getPaddingUnitsLeft() { return paddingUnitsLeft; }

    @Override
    public void setPaddingUnitsTop(int units) { this.paddingUnitsTop = units; }

    @Override
    public void setPaddingUnitsRight(int units) { this.paddingUnitsRight = units; }

    @Override
    public void setPaddingUnitsDown(int units) { this.paddingUnitsDown = units; }

    @Override
    public void setPaddingUnitsLeft(int units) { this.paddingUnitsLeft = units; }

    @SuppressWarnings("unchecked")
    public T onClick(Runnable callback) {
        this.onClick = callback;
        return (T) this;
    }

    protected void applyBaseLayout(Node node, ThemeInterface theme) {
        if (!(node instanceof Region region)) return;

        if (minWidth > 0) {
            region.setMinWidth(ScaleProvider.scale(minWidth));
        }
        if (width > 0) {
            region.setPrefWidth(ScaleProvider.scale(width));
        }
        if (maxWidth > 0) {
            region.setMaxWidth(ScaleProvider.scale(maxWidth));
        }
        if (maxHeight > 0) {
            region.setMaxHeight(ScaleProvider.scale(maxHeight));
        }
        if (height > 0) {
            double scaled = ScaleProvider.scale(height);
            region.setPrefHeight(scaled);
            region.setMinHeight(scaled);
            region.setMaxHeight(scaled);
        }

        region.setPadding(resolvePadding(theme));

        if (onClick != null) {
            region.setOnMouseClicked(ev -> onClick.run());
        }
    }
}
