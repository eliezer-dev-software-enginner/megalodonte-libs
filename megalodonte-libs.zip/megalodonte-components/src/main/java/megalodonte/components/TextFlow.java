package megalodonte.components;
import megalodonte.base.components.Component;
public class TextFlow extends Component {
    private final javafx.scene.text.TextFlow container;

    /**
     * Use another constructor
     * @param content
     */
    @Deprecated(forRemoval = true)
    public TextFlow(Component content) {
        super((new javafx.scene.text.TextFlow()), null);
        
        this.container = (javafx.scene.text.TextFlow) node;
        //setupContainerBehavior();
        
        // Adicionar conteúdo
        this.container.getChildren().add(content.getJavaFxNode());
    }

    public TextFlow(Text textComponent) {
        super((new javafx.scene.text.TextFlow()), null);

        this.container = (javafx.scene.text.TextFlow) node;
        //setupContainerBehavior();

        // Adicionar conteúdo
        this.container.getChildren().add(textComponent.getJavaFxNode());
    }

//    private void setupContainerBehavior() {
//        // Impedir crescimento automático do Region
//        container.setMaxSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
//
//        // Tornar clicável
//        container.setPickOnBounds(true);
//    }

}