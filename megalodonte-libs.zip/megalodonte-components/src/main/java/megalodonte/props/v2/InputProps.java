package megalodonte.props.v2;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import megalodonte.base.scale.ScaleProvider;
import megalodonte.base.theme.ThemeInterface;
import megalodonte.props.Props;
import megalodonte.props.TextComponentProps;
import megalodonte.props.TextTone;

import static megalodonte.styles.util.StyleUtils.*;
import megalodonte.props.Paddable;

/**
 * Props para {@link megalodonte.components.v2.Input} — separado de
 * {@link megalodonte.props.InputProps} porque o node estilizado aqui não é um
 * {@code TextInputControl} (não existe nenhum Control nativo por baixo), então
 * não faz sentido reaproveitar uma classe cuja API pressupõe isso.
 */
public class InputProps extends TextComponentProps<InputProps> implements Paddable<InputProps> {

    private String placeholder;
    private int height;
    private int width;
    private boolean fillWidth;
    private int maxWidth;
    private TextTone tone = TextTone.PRIMARY;
    private boolean disabled;

    protected String bgColor;
    protected String borderColor;
    protected int borderWidth;
    protected int borderRadius;
    protected String placeholderColor;

    protected int paddingUnitsTop = UNSET;
    protected int paddingUnitsRight = UNSET;
    protected int paddingUnitsDown = UNSET;
    protected int paddingUnitsLeft = UNSET;

    public InputProps tone(TextTone tone) {
        this.tone = tone;
        return this;
    }

    public TextTone getTone() {
        return tone;
    }

    public InputProps height(int height) {
        this.height = height;
        return this;
    }

    public InputProps fillWidth() {
        this.fillWidth = true;
        return this;
    }

    public InputProps width(int width) {
        this.width = width;
        return this;
    }

    public InputProps maxWidth(int maxWidth) {
        this.maxWidth = maxWidth;
        return this;
    }

    public InputProps placeHolder(String text) {
        this.placeholder = text;
        return this;
    }

    public InputProps disable() {
        this.disabled = true;
        return this;
    }

    public InputProps bgColor(String bgColor) {
        this.bgColor = bgColor;
        return this;
    }

    public InputProps borderColor(String borderColor) {
        this.borderColor = borderColor;
        return this;
    }

    public InputProps borderWidth(int borderWidth) {
        this.borderWidth = borderWidth;
        return this;
    }

    public InputProps borderRadius(int borderRadius) {
        this.borderRadius = borderRadius;
        return this;
    }

    @Override
    public int getPaddingUnitsTop() { return paddingUnitsTop; }

    @Override
    public int getPaddingUnitsRight() { return paddingUnitsRight; }

    @Override
    public int getPaddingUnitsDown() { return paddingUnitsDown; }

    @Override
    public int getPaddingUnitsLeft() { return paddingUnitsLeft; }

    @Override
    public void setPaddingUnitsTop(int units) { this.paddingUnitsTop = units; }

    @Override
    public void setPaddingUnitsRight(int units) { this.paddingUnitsRight = units; }

    @Override
    public void setPaddingUnitsDown(int units) { this.paddingUnitsDown = units; }

    @Override
    public void setPaddingUnitsLeft(int units) { this.paddingUnitsLeft = units; }

    public boolean isDisabled() {
        return disabled;
    }

    public String getPlaceholder() {
        return placeholder;
    }

    @Override
    protected void applyTheme(Node node, Props props, ThemeInterface theme) {
        if (!(node instanceof StackPane outer)) return;
        if (!(outer.getChildren().get(0) instanceof Region surface)) return;

        var text = (Text) surface.lookup("#megalodonte-input-text");
        var placeholderNode = (Text) surface.lookup("#megalodonte-input-placeholder");
        var caret = surface.lookup("#megalodonte-input-caret");
        var selectionRect = surface.lookup("#megalodonte-input-selection");
        if (text == null || placeholderNode == null) return;

        // O tamanho vai no StackPane externo (outer), não no Pane interno
        // (surface) — StackPane sempre redimensiona o filho gerenciado pra
        // preencher a si mesmo, então constranger só o outer já basta, e
        // constranger o surface por engano deixa o outer sem limite de
        // tamanho (herda Double.MAX_VALUE do Region por padrão), fazendo o
        // campo "escapar" do layout do pai quando ele tenta esticar/centralizar.
        if (height > 0) {
            double scaled = ScaleProvider.scale(height);
            outer.setPrefHeight(scaled);
            outer.setMinHeight(scaled);
            outer.setMaxHeight(scaled);
        } else {
            outer.setMaxHeight(Region.USE_PREF_SIZE);
        }

        if (fillWidth) {
            // Estica na largura disponível do pai — mesmo padrão de ButtonProps.fillWidth().
            // width(int), se setado junto, vira só um piso (minWidth) em vez de trava fixa,
            // já que setMaxWidth(scaled) logo abaixo (bloco width>0) sobrescreveria o
            // MAX_VALUE de novo se fosse executado depois — por isso os dois blocos são
            // mutuamente exclusivos (else if), não sequenciais.
            outer.setMaxWidth(Double.MAX_VALUE);
            if (width > 0) {
                double scaled = ScaleProvider.scale(width);
                outer.setPrefWidth(scaled);
                outer.setMinWidth(scaled);
            } else {
                outer.setMinWidth(Region.USE_PREF_SIZE);
            }
        } else if (width > 0) {
            double scaled = ScaleProvider.scale(width);
            outer.setPrefWidth(scaled);
            outer.setMinWidth(scaled);
            outer.setMaxWidth(scaled);
        } else {
            outer.setMaxWidth(Region.USE_PREF_SIZE);
        }

        if (maxWidth > 0) {
            outer.setMaxWidth(ScaleProvider.scale(maxWidth));
        }

        if (disabled) {
            surface.setDisable(true);
        }

        if (placeholder != null) {
            placeholderNode.setText(placeholder);
        }

        int fontSize = getFontSize() != null ? ScaleProvider.scale(getFontSize()) : theme.typography().body();
        updateFontSize(text, fontSize);
        updateFontSize(placeholderNode, fontSize);

        applyFontStyling(text);

        String finalTextColor = getFinalInputTextColor(theme);
        updateTextColor(text, finalTextColor);
        if (caret != null) updateTextColor(caret, finalTextColor);
        if (selectionRect != null) updateTextColor(selectionRect, theme.colors().selection());

        String finalPlaceholderColor = placeholderColor != null && !placeholderColor.isBlank()
                ? placeholderColor : theme.colors().placeholder();
        updateTextColor(placeholderNode, finalPlaceholderColor);

        String finalBgColor = getFinalBackgroundColor(theme, bgColor);
        updateBackgroundColor(surface, finalBgColor);

        String finalBorderColor = getFinalBorderColor(theme, borderColor);
        updateBorderColor(surface, finalBorderColor);

        int finalBorderWidth = borderWidth > 0 ? ScaleProvider.scale(borderWidth) : theme.border().width();
        if (finalBorderWidth > 0) {
            updateBorderWidth(surface, finalBorderWidth);
        }

        int finalRadius = borderRadius > 0 ? ScaleProvider.scale(borderRadius) : theme.border().radiusMd();
        updateBorderRadius(surface, finalRadius);
        updateBorderRadius(outer, finalRadius);
        updateBorderColor(outer, "transparent");

        surface.setPadding(v2ContentCompensatedPadding(theme));
    }

    /**
     * Padding da surface pra igualar a altura TOTAL do v2 à do input nativo.
     * A TextFieldSkin (v1) reserva ~1px a mais que a altura do {@code Text} cru
     * do v2 pra mesma fonte (métrica interna da skin, não reproduzível via
     * Text), então o padding vertical da surface ganha 0.5 por lado — somado,
     * fecha o outer do v2 no mesmo valor do outer do v1 medido com a mesma
     * fonte. Sem isso o v2 renderiza ~1px menor/“mais baixo” que o nativo na
     * mesma grade.
     */
    private Insets v2ContentCompensatedPadding(ThemeInterface theme) {
        Insets pad = resolvePadding(theme);
        return new Insets(pad.getTop() + 0.5, pad.getRight(),
                pad.getBottom() + 0.5, pad.getLeft());
    }

    private String getFinalInputTextColor(ThemeInterface theme) {
        if (textColor != null && !textColor.isBlank()) {
            return textColor;
        }
        return switch (tone) {
            case PRIMARY -> theme.colors().textPrimary();
            case SECONDARY, DISABLED -> theme.colors().textSecondary();
            case INVERTED -> theme.colors().background();
        };
    }
}
