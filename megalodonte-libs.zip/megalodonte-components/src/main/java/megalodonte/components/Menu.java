package megalodonte.components;

import javafx.geometry.Point2D;
import javafx.scene.Node;
import javafx.scene.layout.Region;
import javafx.stage.Popup;
import megalodonte.base.components.Component;
import megalodonte.base.components.IconInterface;
import megalodonte.base.theme.ThemeInterface;
import megalodonte.base.theme.ThemeManager;
import megalodonte.components.layout_components.Column;
import megalodonte.components.layout_components.Container;
import megalodonte.components.layout_components.Row;
import megalodonte.props.ColumnProps;
import megalodonte.props.ContainerProps;
import megalodonte.props.RowProps;
import megalodonte.props.TextProps;

import java.util.ArrayList;
import java.util.List;

import static megalodonte.styles.util.StyleUtils.updateBackgroundColor;
import static megalodonte.styles.util.StyleUtils.updateBorderColor;
import static megalodonte.styles.util.StyleUtils.updateBorderRadius;
import static megalodonte.styles.util.StyleUtils.updateBorderWidth;
import static megalodonte.styles.util.StyleUtils.updateTextColor;

/**
 * Menu suspenso (dropdown) próprio, sem depender de javafx.scene.control.Menu —
 * o menu nativo usa Label internamente com uma área de clique que às vezes não
 * cobre a linha inteira (é preciso acertar o texto). Aqui cada linha é um
 * Clickable de bounds cheios (StackPane com pickOnBounds), e tudo é construído
 * com os componentes temáticos da lib (Container/Card/Text), então segue o tema
 * da aplicação em vez do look nativo do SO.
 */
public class Menu {
    private static Popup currentlyOpen;

    private final List<MenuItem> items = new ArrayList<>();
    private final javafx.scene.text.Text triggerLabel;
    private final Clickable trigger;
    private final Popup popup = new Popup();

    public Menu(String title) {
        var theme = ThemeManager.theme();

        Text label = new Text(title, new TextProps().textColor(theme.colors().textPrimary()).bold());
        this.triggerLabel = (javafx.scene.text.Text) label.getJavaFxNode();

        var triggerContainer = new Container(new ContainerProps().paddingAll(8)).children(label);
        addHoverHighlight(triggerContainer.getJavaFxNode(), theme);

        this.trigger = new Clickable(triggerContainer).onClick(this::toggle);

        popup.setAutoHide(true);
        popup.setOnAutoHide(e -> {
            if (currentlyOpen == popup) currentlyOpen = null;
        });
    }

    public Menu addItem(MenuItem item) {
        items.add(item);
        return this;
    }

    public Menu item(IconInterface icon, String title, Runnable action) {
        return addItem(new MenuItem(icon, title, action));
    }

    public Menu item(MenuItem item) {
        return addItem(item);
    }

    public Menu item(String title, Runnable action) {
        return addItem(new MenuItem(title, action));
    }

    public Menu itemIf(boolean condition, String title, Runnable action) {
        if (condition) {
            item(title, action);
        }
        return this;
    }

    public Menu itemIf(boolean condition, IconInterface icon, String title, Runnable action) {
        if (condition) {
            item(icon, title, action);
        }
        return this;
    }

    public List<MenuItem> getItems() {
        return new ArrayList<>(items);
    }

    public String getTitle() {
        return triggerLabel.getText();
    }

    public void setTitle(String title) {
        triggerLabel.setText(title);
    }

    /**
     * Sobrescreve a cor padrão do título ({@code theme.colors().textPrimary()}) — útil quando a
     * MenuBar tem um fundo escuro custom. Precisa ir pelo mesmo mecanismo de estilo inline
     * ({@code -fx-fill}) que {@code TextProps} usa na construção — um {@code setFill()} direto
     * é sobrescrito de volta pelo próximo processamento de CSS do JavaFX, porque o estilo
     * inline já aplicado tem prioridade mais alta que uma propriedade setada via API.
     */
    public Menu textColor(String color) {
        updateTextColor(triggerLabel, color);
        return this;
    }

    Component getTrigger() {
        return trigger;
    }

    private void toggle() {
        if (popup.isShowing()) {
            popup.hide();
            return;
        }
        if (currentlyOpen != null && currentlyOpen.isShowing()) {
            currentlyOpen.hide();
        }

        popup.getContent().setAll(buildDropdown().getJavaFxNode());

        Node triggerNode = trigger.getJavaFxNode();
        Point2D screenPoint = triggerNode.localToScreen(0, triggerNode.getBoundsInLocal().getHeight());
        popup.show(triggerNode, screenPoint.getX(), screenPoint.getY());
        currentlyOpen = popup;
    }

    private Component buildDropdown() {
        var theme = ThemeManager.theme();
        var column = new Column(new ColumnProps());

        if (items.isEmpty()) {
            column.c_child(new Container(new ContainerProps().paddingAll(12))
                    .children(new Text("Sem opções", new TextProps().textColor(theme.colors().textSecondary()))));
        } else {
            for (MenuItem item : items) {
                column.c_child(menuItemRow(item, theme));
            }
        }

        // Não usa Card aqui de propósito: CardProps liga um DropShadow que troca de
        // raio (8→16) no hover, e como o Popup recalcula o próprio tamanho a cada
        // layout, isso fazia a janela do popup "pulsar"/reposicionar a cada
        // passada de mouse. Aqui a sombra é fixa (não reage a hover).
        var wrapper = new Container(new ContainerProps().paddingAll(4)).children(column);
        var wrapperNode = wrapper.getJavaFxNode();
        updateBackgroundColor(wrapperNode, theme.colors().surface());
        updateBorderRadius(wrapperNode, theme.border().radiusMd());
        updateBorderColor(wrapperNode, theme.colors().border());
        updateBorderWidth(wrapperNode, 1);
        wrapperNode.setEffect(new javafx.scene.effect.DropShadow(8, javafx.scene.paint.Color.rgb(0, 0, 0, 0.2)));

        return wrapper;
    }

    private Component menuItemRow(MenuItem item, ThemeInterface theme) {
        Text label = new Text(item.getTitle(), new TextProps().textColor(theme.colors().textPrimary()));

        Component content = item.getIcon() != null
                ? new Row(new RowProps()).children(Component.CreateFromJavaFxNode(item.getIcon().getJavaFxNode()), label)
                : label;

        var itemContainer = new Container(new ContainerProps().paddingAll(8))
                .children(content);
        addHoverHighlight(itemContainer.getJavaFxNode(), theme);

        var clickable = new Clickable(itemContainer).onClick(() -> {
            popup.hide();
            item.run();
        });
        // Clickable trava o próprio node em USE_PREF_SIZE (pra não crescer sem
        // querer em outros usos) — aqui a gente quer o oposto: a linha precisa
        // esticar até a largura da Column, senão o fundo do hover só cobre o
        // texto em vez da linha inteira.
        ((Region) clickable.getJavaFxNode()).setMaxWidth(Double.MAX_VALUE);
        return clickable;
    }

    private void addHoverHighlight(Node node, ThemeInterface theme) {
        node.setOnMouseEntered(e -> updateBackgroundColor(node, theme.colors().hover()));
        node.setOnMouseExited(e -> updateBackgroundColor(node, "transparent"));
    }

    public static Menu of(String title) {
        return new Menu(title);
    }
}
