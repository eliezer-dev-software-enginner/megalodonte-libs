package megalodonte.props;

import javafx.application.Platform;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.DatePicker;
import javafx.stage.PopupWindow;
import javafx.stage.Window;
import megalodonte.base.scale.ScaleProvider;
import megalodonte.base.state.ReadableState;
import megalodonte.base.state.State;
import megalodonte.base.theme.ThemeInterface;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

import static megalodonte.styles.util.StyleUtils.*;

public class DatePickerProps extends Props implements Paddable<DatePickerProps> {
    private DateTimeFormatter formatter;
    private Locale locale;
    private String promptText;
    private Boolean editable;
    private ReadableState<LocalDate> valueState;
    private String color;
    private Integer fontSize;

    public DatePickerProps formatter(DateTimeFormatter formatter) {
        this.formatter = formatter;
        return this;
    }
    
    public DatePickerProps locale(Locale locale) {
        this.locale = locale;
        return this;
    }
    
    public DatePickerProps placeHolder(String placeHolder) {
        this.promptText = placeHolder;
        return this;
    }
    
    public DatePickerProps editable(Boolean editable) {
        this.editable = editable;
        return this;
    }
    
    public DatePickerProps editable(boolean editable) {
        this.editable = editable;
        return this;
    }
    
    public DatePickerProps value(State<LocalDate> state) {
        this.valueState = state;
        return this;
    }
    
    public DatePickerProps pattern(String pattern) {
        this.formatter = DateTimeFormatter.ofPattern(pattern, locale != null ? locale : Locale.getDefault());
        return this;
    }
    
    public DatePickerProps pattern(String pattern, Locale locale) {
        this.formatter = DateTimeFormatter.ofPattern(pattern, locale);
        this.locale = locale;
        return this;
    }


    public DatePickerProps fontSize(int fontSize){
        this.fontSize = fontSize;
        return this;
    }

    private TextTone tone = TextTone.PRIMARY;

    public DatePickerProps tone(TextTone tone) {
        this.tone = tone;
        return this;
    }

    public TextTone getTone() {
        return tone;
    }

    private int height;
    private int width;

    public DatePickerProps height(int height){
        this.height = height;
        return this;
    }
    public DatePickerProps width(int width){
        this.width = width;
        return this;
    }

    public DatePickerProps color(String color){
        this.color = color;
        return this;
    }

    protected String textColor;
    protected String placeholderColor;

    // Common styling properties
    protected String bgColor;
    protected String borderColor;
    protected int borderWidth;
    protected int borderRadius;

    protected int paddingUnitsTop = UNSET;
    protected int paddingUnitsRight = UNSET;
    protected int paddingUnitsDown = UNSET;
    protected int paddingUnitsLeft = UNSET;

    // Fluent API methods
    @SuppressWarnings("unchecked")
    public DatePickerProps  bgColor(String bgColor) {
        this.bgColor = bgColor;
        return this;
    }

    @SuppressWarnings("unchecked")
    public DatePickerProps borderColor(String borderColor) {
        this.borderColor = borderColor;
        return this;
    }

    @SuppressWarnings("unchecked")
    public DatePickerProps borderWidth(int borderWidth) {
        this.borderWidth = borderWidth;
        return this;
    }

    @SuppressWarnings("unchecked")
    public DatePickerProps borderRadius(int borderRadius) {
        this.borderRadius = borderRadius;
        return this;
    }

    @Override
    public int getPaddingUnitsTop() { return paddingUnitsTop; }

    @Override
    public int getPaddingUnitsRight() { return paddingUnitsRight; }

    @Override
    public int getPaddingUnitsDown() { return paddingUnitsDown; }

    @Override
    public int getPaddingUnitsLeft() { return paddingUnitsLeft; }

    @Override
    public void setPaddingUnitsTop(int units) { this.paddingUnitsTop = units; }

    @Override
    public void setPaddingUnitsRight(int units) { this.paddingUnitsRight = units; }

    @Override
    public void setPaddingUnitsDown(int units) { this.paddingUnitsDown = units; }

    @Override
    public void setPaddingUnitsLeft(int units) { this.paddingUnitsLeft = units; }

    @Override
    protected void applyTheme(Node node, Props props, ThemeInterface theme) {
        if (!(node instanceof DatePicker datePicker)) return;

        if (formatter != null) {
            datePicker.setConverter(new javafx.util.StringConverter<LocalDate>() {
                @Override
                public String toString(LocalDate date) {
                    return date != null ? formatter.format(date) : "";
                }

                @Override
                public LocalDate fromString(String string) {
                    return (string != null && !string.isBlank())
                            ? LocalDate.parse(string, formatter)
                            : null;
                }
            });
        }

        if (promptText != null) {
            datePicker.setPromptText(promptText);
        }

        if (editable != null) {
            datePicker.setEditable(editable);
        }

        if (valueState != null) {
            valueState.subscribe(date -> {
                if (date != null) {
                    datePicker.setValue(date);
                }
            });

            datePicker.valueProperty().addListener((obs, oldVal, newVal) -> {
                if (newVal != null && valueState instanceof State) {
                    ((State<LocalDate>) valueState).set(newVal);
                }
            });
        }

        int finalFontSize = fontSize != null ? ScaleProvider.scale(fontSize) : theme.typography().small();
        updateFontSize(datePicker, finalFontSize);

        if (color != null) {
            updateTextColor_Input(datePicker, color);
        }


        if(height > 0){
            double scaled = ScaleProvider.scale(height);
            datePicker.setPrefHeight(scaled);
            datePicker.setMinHeight(scaled);
            datePicker.setMaxHeight(scaled);
        }

        if(width > 0){
            double scaled = ScaleProvider.scale(width);
            datePicker.setPrefWidth(scaled);
            datePicker.setMinWidth(scaled);
            datePicker.setMaxWidth(scaled);
        }

        // Apply background styling
        applyBackgroundStyling(datePicker, theme, bgColor);
        applyInnerTransparency(datePicker);

        datePicker.setPadding(resolvePadding(theme));

        // Apply border styling
        applyBorderStyling(datePicker, theme);

        // Modena renders text-field-like controls (DatePicker included) with several
        // stacked background/border layers, each with its own inset and radius, to get
        // the default bevel + focus-glow look. Overriding just the color leaves those
        // extra layers active with mismatched insets, which shows up as a slightly
        // stepped/uneven edge ("pixelated" border). Forcing a single layer here fixes
        // that, but it also kills modena's own focus glow — so focus feedback is
        // re-added explicitly below, using the theme's color instead of modena's blue.
        applyStyleProperty(datePicker, "0", "-fx-background-insets");
        applyStyleProperty(datePicker, "0", "-fx-border-insets");
        applyFocusFeedback(datePicker, theme);

        // Apply text styling for the date picker
        applyDateInputTextStyling(datePicker, theme);

        applyCalendarPopupTheme(datePicker, theme);
    }

    /**
     * O popup do calendário (mês/ano, dias) roda numa Scene separada da do
     * DatePicker (mesmo problema documentado em Select/SelectProps pro popup do
     * ComboBox) — nada do que a gente aplica no próprio DatePicker chega até lá
     * por herança normal de CSS. Só dá pra alcançar via {@link Window#getWindows()}
     * depois que o popup abre, procurando a janela cuja Scene tem ".date-picker-popup".
     * Os seletores/estrutura (".month-year-pane", ".day-cell", ".selected", ".today",
     * ".previous-month"/".next-month") vêm do modena.css real (conferido no jar do
     * JavaFX), não inventados.
     */
    private void applyCalendarPopupTheme(DatePicker datePicker, ThemeInterface theme) {
        datePicker.showingProperty().addListener((obs, wasShowing, isShowing) -> {
            if (isShowing) {
                Platform.runLater(() -> styleCalendarPopup(theme));
            }
        });
    }

    /**
     * O DatePicker não é um node único — por baixo, o editor (.text-field) e o
     * arrow-button carregam seus próprios backgrounds opacos do Modena, cada um
     * pintado independentemente do node externo. Sem isso, mesmo com a cor certa
     * aplicada no datePicker via applyBackgroundStyling, esses filhos internos
     * continuam visíveis por cima, aparecendo como um artefato cinza dentro do
     * campo. Torná-los transparentes deixa a cor do node externo aparecer por trás.
     */
    private void applyInnerTransparency(DatePicker datePicker) {
        applyStyleProperty(datePicker.getEditor(), "transparent", "-fx-background-color");

        Runnable apply = () -> {
            var arrowButton = datePicker.lookup(".arrow-button");
            if (arrowButton != null) {
                applyStyleProperty(arrowButton, "transparent", "-fx-background-color");
            }
        };

        if (datePicker.getSkin() != null) {
            Platform.runLater(apply);
        } else {
            datePicker.skinProperty().addListener((obs, oldSkin, newSkin) -> {
                if (newSkin != null) Platform.runLater(apply);
            });
        }
    }

    private void styleCalendarPopup(ThemeInterface theme) {
        for (Window window : Window.getWindows()) {
            if (!(window instanceof PopupWindow)) continue;

            Scene scene = window.getScene();
            if (scene == null || scene.getRoot() == null) continue;

            Parent root = scene.getRoot();
            Node popupNode = root.getStyleClass().contains("date-picker-popup")
                    ? root : root.lookup(".date-picker-popup");
            if (!(popupNode instanceof Parent popup)) continue;

            updateBackgroundColor(popup, theme.colors().surface());

            for (Node pane : popup.lookupAll(".month-year-pane")) {
                updateBackgroundColor(pane, theme.colors().primary());
            }
            for (Node label : popup.lookupAll(".spinner .label")) {
                updateTextColor_Input(label, "white");
            }
            for (Node arrow : popup.lookupAll(".left-arrow, .right-arrow")) {
                applyStyleProperty(arrow, "white", "-fx-background-color");
            }
            for (Node dayName : popup.lookupAll(".day-name-cell")) {
                updateBackgroundColor(dayName, theme.colors().surface());
                updateTextColor_Input(dayName, theme.colors().textSecondary());
            }
            for (Node cell : popup.lookupAll(".day-cell")) {
                wireDayCell(cell, theme);
            }
        }
    }

    /**
     * A célula do dia sinaliza selecionado/hoje via style class (".selected",
     * ".today"), não pseudo-classe — então reage-se a mudanças na styleClass list,
     * mais o hover normal do Node, pra recolorir a cada troca de estado.
     */
    private void wireDayCell(Node cell, ThemeInterface theme) {
        if (Boolean.TRUE.equals(cell.getProperties().get("megalodonte-day-cell-wired"))) {
            styleDayCell(cell, theme);
            return;
        }
        cell.getProperties().put("megalodonte-day-cell-wired", true);

        styleDayCell(cell, theme);
        cell.hoverProperty().addListener((obs, was, isHover) -> styleDayCell(cell, theme));
        cell.getStyleClass().addListener((javafx.collections.ListChangeListener<String>) change -> styleDayCell(cell, theme));
    }

    private void styleDayCell(Node cell, ThemeInterface theme) {
        boolean selected = cell.getStyleClass().contains("selected");
        boolean today = cell.getStyleClass().contains("today");
        boolean otherMonth = cell.getStyleClass().contains("previous-month") || cell.getStyleClass().contains("next-month");

        String bg;
        String textColor;
        String borderColor;

        if (selected) {
            bg = theme.colors().primary();
            textColor = "white";
            borderColor = theme.colors().primary();
        } else if (cell.isHover()) {
            bg = theme.colors().hover();
            textColor = theme.colors().textPrimary();
            borderColor = theme.colors().border();
        } else {
            bg = theme.colors().surface();
            textColor = otherMonth ? theme.colors().placeholder() : theme.colors().textPrimary();
            borderColor = today ? theme.colors().primary() : theme.colors().border();
        }

        updateBackgroundColor(cell, bg);
        updateTextColor_Input(cell, textColor);
        updateBorderColor(cell, borderColor);
    }

    /**
     * Modena's default focus feedback around DatePicker/ComboBoxBase-like controls
     * is a soft glow/halo (a dropshadow-ish effect driven by -fx-faint-focus-color),
     * not just a border color change — mesmo trocando a cor pelo focusRing do tema,
     * o efeito de "brilho" ao redor continua feio/deslocado do resto da UI. Zera
     * -fx-faint-focus-color (mata o glow) e mantém só a troca de cor da borda em si
     * via listener abaixo, que é o único feedback visual de foco desejado.
     */
    private void applyFocusFeedback(DatePicker datePicker, ThemeInterface theme) {
        String restingBorderColor = getFinalBorderColor(theme, borderColor);
        String focusColor = theme.colors().focusRing();

        applyStyleProperty(datePicker, focusColor, "-fx-focus-color");
        applyStyleProperty(datePicker, "transparent", "-fx-faint-focus-color");

        datePicker.focusedProperty().addListener((obs, wasFocused, isFocused) ->
                updateBorderColor(datePicker, isFocused ? focusColor : restingBorderColor));
    }

    /**
     * Applies text styling specific to DatePicker input field.
     */
    private void applyDateInputTextStyling(DatePicker datePicker, ThemeInterface theme) {
        String finalTextColor = textColor != null && !textColor.isBlank() ?
                textColor : theme.colors().textPrimary();

        updateTextColor_Input(datePicker.getEditor(), finalTextColor);

        String finalPlaceholderColor = placeholderColor != null && !placeholderColor.isBlank() ?
                placeholderColor : theme.colors().textSecondary();

        updatePlaceholderColor(datePicker.getEditor(), finalPlaceholderColor);

        int fontSize = theme.typography().body();
        updateFontSize(datePicker.getEditor(), fontSize);

        // Set placeholder font size to match
        updatePlaceholderFontSize(datePicker.getEditor(), fontSize);
    }

    /**
     * Applies common border styling.
     */
    protected void applyBorderStyling(Node node, ThemeInterface theme) {
        String finalBorderColor = getFinalBorderColor(theme, borderColor);
        updateBorderColor(node, finalBorderColor);

        int finalBorderWidth = getFinalBorderWidth(theme, ScaleProvider.scale(borderWidth));
        if (finalBorderWidth > 0) {
            updateBorderWidth(node, finalBorderWidth);
        }

        int finalBorderRadius = getFinalBorderRadius(theme, ScaleProvider.scale(borderRadius));
        updateBorderRadius(node, finalBorderRadius);
    }
}