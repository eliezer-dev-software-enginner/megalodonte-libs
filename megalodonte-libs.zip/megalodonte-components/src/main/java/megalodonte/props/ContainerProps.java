package megalodonte.props;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import megalodonte.base.scale.ScaleProvider;
import megalodonte.base.theme.ThemeInterface;

import java.util.Objects;

import static megalodonte.styles.util.StyleUtils.applyBackgroundStyling;

public class ContainerProps extends LayoutProps<ContainerProps> {

    protected String bgColor;
    protected String bgImage;

    private boolean fillHeight = false;

    public ContainerProps fillHeight() {
        this.fillHeight = true;
        return this;
    }

    public boolean hasFillHeight() {
        return fillHeight;
    }

    // Fluent API methods
    @SuppressWarnings("unchecked")
    public ContainerProps bgColor(String bgColor) {
        Objects.requireNonNull(bgColor);
        this.bgColor = bgColor;
        return this;
    }

    /**
     * Has priority over bgColor
     * @param url
     * @return
     */
    public ContainerProps bgImage(String url) {
        Objects.requireNonNull(url);
        this.bgImage = url;
        return this;
    }

    @Override
    protected void applyTheme(Node node, Props props, ThemeInterface theme) {
        if (node instanceof Pane node_) {
            applyBaseLayout(node, theme);

            // applyBaseLayout() não aplica spacingUnits — cada Props que estica de
            // LayoutProps (Column/Row/FlowRow) seta o gap por conta própria depois,
            // e Container esquecia de fazer o mesmo, então spacingOf(...) era
            // guardado no field mas nunca chegava no VBox de verdade.
            if (spacingUnits > 0 && node_ instanceof VBox vBox) {
                vBox.setSpacing(ScaleProvider.scale(spacingUnits));
            }

            if (fillHeight) {
                node_.setMaxHeight(Double.MAX_VALUE);
                VBox.setVgrow(node, Priority.ALWAYS);
            }

            if (bgImage != null) {
                var url = getClass().getResource(bgImage);
                if (url != null) {
                    var image = new javafx.scene.image.Image(url.toExternalForm());
                    var bgImg = new javafx.scene.layout.BackgroundImage(
                            image,
                            javafx.scene.layout.BackgroundRepeat.NO_REPEAT,
                            javafx.scene.layout.BackgroundRepeat.NO_REPEAT,
                            javafx.scene.layout.BackgroundPosition.CENTER,
                            new javafx.scene.layout.BackgroundSize(
                                    1.0, 1.0,
                                    true, true,
                                    false, true  // cover
                            )
                    );
                    node_.setBackground(new javafx.scene.layout.Background(bgImg));
                }
            } else if (bgColor != null) {
                applyBackgroundStyling(node, theme, bgColor);
            }
        }
    }

//    @Override
//    protected void applyTheme(Node node, Props props, ThemeInterface theme) {
//        if (node instanceof Pane node_) {
//            applyBaseLayout(node);
//
//            if (fillHeight) {
//                VBox.setVgrow(node, Priority.ALWAYS);
//            }
//
//            byte type = (byte) (bgImage != null? 1 : 0);
//            // Apply all common theme-aware styling
//            applyBackgroundStyling(node, theme,  bgImage != null? bgImage : bgColor, type);
//        }
//    }
}
