package megalodonte.props;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import megalodonte.base.scale.ScaleProvider;
import megalodonte.base.theme.ThemeInterface;

import java.util.Objects;

import static megalodonte.styles.util.StyleUtils.applyBackgroundStyling;

public class ColumnProps extends LayoutProps<ColumnProps> {
    private boolean fillHeight;
    private boolean fillWidth;
    protected String bgColor;

    private enum Alignment {CENTER_HORIZONTALLY, CENTER_VERTICALLY}
    private Alignment alignment;

    public ColumnProps bgColor(String bgColor) {
        this.bgColor = bgColor;
        return this;
    }

    public ColumnProps centerHorizontally() {
        alignment = Alignment.CENTER_HORIZONTALLY;
        return this;
    }

    public ColumnProps centerVertically() {
        alignment = Alignment.CENTER_VERTICALLY;
        return this;
    }

    public ColumnProps fillHeight(){
        fillHeight = true;
        return this;
    }

    /**
     * Faz a Column crescer horizontalmente quando o pai for um Row/HBox,
     * ocupando o espaço disponível em vez de encolher pro tamanho do conteúdo.
     */
    public ColumnProps fillWidth(){
        fillWidth = true;
        return this;
    }

    @Override
    protected void applyTheme(Node node, Props props, ThemeInterface theme) {
        if (node instanceof VBox vBox) {
            applyBaseLayout(node, theme);

            if (spacingUnits > 0) {
                vBox.setSpacing(ScaleProvider.scale(spacingUnits));
            }

            if (alignment != null) {
                if (alignment.equals(Alignment.CENTER_HORIZONTALLY)) {
                    vBox.setAlignment(Pos.TOP_CENTER);
                    vBox.setFillWidth(false);
                }
                if (alignment.equals(Alignment.CENTER_VERTICALLY)) {
                    vBox.setAlignment(Pos.CENTER);
                }
            }

            if(fillHeight){
                VBox.setVgrow(node, Priority.ALWAYS);
            }

            if (fillWidth) {
                vBox.setMaxWidth(Double.MAX_VALUE);
                HBox.setHgrow(node, Priority.ALWAYS);
            }

            if (bgColor != null) {
                applyBackgroundStyling(node, theme, bgColor);
            }
        }
    }
}
